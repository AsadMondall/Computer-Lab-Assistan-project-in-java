import java.io.*;
import java.util.Scanner;
class Register {
String Email;
String user_Name;
String user_id;
String password;

Register(String Email, String user_Name,String user_id,String password)
{
this.Email = Email;
this.user_Name=user_Name;
this.user_id= user_id;
this.password=password;
}
void write_File()
{
try
{
BufferedWriter wr = new BufferedWriter(new FileWriter("Admin_information.txt"));
wr.write(Email);
wr.write(user_Name);
wr.write(user_id);
wr.write(password);
wr.close();
}
catch(IOException e)
{}

}


}


class Login extends Register {
    String u_id;
    String u_pass;
    Login(String u_id,String u_pass )
    {
        this.u_id= u_id;
        this.u_pass=u_pass;
	}
	
        if (u_id.equals(user_id)&&u_pass.equals(password))
        {
          System.out.println("Login Successful!!!!!");
        }
        else
        {
            System.out.println("Login Failed");
        }
      
       
        
    }
    

public class Main {
    
public static void main(String[] args) {
    
     Scanner sc = new Scanner(System.in);
      System.out.println("1.Register\n");
      System.out.println("2.Login\n");
     System.out.println("Choose any option :\n");
     int opt = sc.nextInt();
     switch (opt) {
             case 1 :
             {                 
     System.out.println("Admin Panel information :\n");
     System.out.println("Enter Email_Address :\n");
     String ea = sc.nextLine();
     System.out.println("Enter Name :\n");
     String n = sc.nextLine();
     System.out.println("Enter User_id(combination of letters & numbers) :\n");
     String ui = sc.nextLine();
     System.out.println("Enter password :\n");
     String ps = sc.nextLine();
     Register R = new Register(ea+"\n",n+"\n",ui+"\n",ps+"\n");
     R.write_File();
}
             
             case 2 :
             {
              System.out.println("Enter User_id:\n");
              String u_id = sc.nextLine();
              System.out.println("Enter password :\n");
              String u_pass = sc.nextLine();
              Login lg = new Login(u_id,u_pass); 
             }
           

}
}
}