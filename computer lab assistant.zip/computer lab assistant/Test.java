import java.util.Scanner;
import java.io.*;
import java.awt.Desktop;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;
import static java.lang.System.exit;

abstract class Software {

    static void course_syllabus() {
        try {
            File file = new File("C:\\Users\\USER\\Desktop\\VCLA\\syllabus\\syllabus.txt");
            StringBuffer sb;
            try ( FileReader fr = new FileReader(file)) {
                BufferedReader br = new BufferedReader(fr);
                sb = new StringBuffer();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                    sb.append("\n");
                }
            }
            System.out.println("Contents of File: ");
            System.out.println(sb.toString());
        } catch (IOException e) {
        }
    }

    abstract public void setup1();

    abstract public void setup2();

    abstract public void setup3();

}

interface Operating_System_platform {

    public void Windows();

    public void Mac();

    public void Linux();
}

class programming_language extends Software implements Operating_System_platform {

    public void Windows() {
        try {
            File file = new File("C:\\Users\\USER\\Desktop\\VCLA\\programming language\\windows system requirements.txt");
            StringBuffer sb;
            try ( FileReader fr = new FileReader(file)) {
                BufferedReader br = new BufferedReader(fr);
                sb = new StringBuffer();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                    sb.append("\n");
                }
            }
            System.out.println("Contents of File: ");
            System.out.println(sb.toString());
        } catch (IOException e) {
        }
    }

    public void Linux() {
        try {
            File file = new File("C:\\Users\\USER\\Desktop\\VCLA\\programming language\\linux system requirements.txt");
            StringBuffer sb;
            try ( FileReader fr = new FileReader(file)) {
                BufferedReader br = new BufferedReader(fr);
                sb = new StringBuffer();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                    sb.append("\n");
                }
            }
            System.out.println("Contents of File: ");
            System.out.println(sb.toString());
        } catch (IOException e) {
        }
    }

    public void Mac() {
        try {
            File file = new File("C:\\Users\\USER\\Desktop\\VCLA\\programming language\\mac system requirements.txt");
            StringBuffer sb;
            try ( FileReader fr = new FileReader(file)) {
                BufferedReader br = new BufferedReader(fr);
                sb = new StringBuffer();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                    sb.append("\n");
                }
            }
            System.out.println("Contents of File: ");
            System.out.println(sb.toString());
        } catch (IOException e) {
        }
    }

    ///// setup of c/c++
    public void setup1() {

        Desktop desk = Desktop.getDesktop();
        try {
            // now we enter our URL that we want to open in our
            // default browser
            desk.browse(new URI("https://code.visualstudio.com/docs/cpp/config-mingw"));
        } catch (URISyntaxException | IOException ex) {
			/////Logger logger = Logger.getLogger(MyClass.class.getName());
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    ///////setup of java
    public void setup2() {

        Desktop desk = Desktop.getDesktop();
        try {
            // now we enter our URL that we want to open in our
            // default browser
            desk.browse(new URI("https://www.oracle.com/java/technologies/javase-jdk-7-netbeans-install.html"));
            desk.browse(new URI("https://netbeans.apache.org/kb/docs/java/javase-jdk8.html"));
        } catch (URISyntaxException | IOException ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void setup3() {

        Desktop desk = Desktop.getDesktop();
        try {
            // now we enter our URL that we want to open in our
            // default browser
            desk.browse(new URI("https://www.python.org/downloads/"));
            desk.browse(new URI("https://docs.python.org/3/using/index.html"));
        } catch (URISyntaxException | IOException ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}

////////GRAPHICS CLASS
class Graphics extends Software implements Operating_System_platform {

    public void Windows() {
        try {
            File file = new File("C:\\Users\\USER\\Desktop\\VCLA\\graphics\\system requirements for windows.txt");
            StringBuffer sb;
            try ( FileReader fr = new FileReader(file)) {
                BufferedReader br = new BufferedReader(fr);
                sb = new StringBuffer();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                    sb.append("\n");
                }
            }
            System.out.println("Contents of File: ");
            System.out.println(sb.toString());
        } catch (IOException e) {
        }
    }

    public void Linux() {
        try {
            File file = new File("C:\\Users\\USER\\Desktop\\VCLA\\graphics\\system requirement for linux.txt");
            StringBuffer sb;
            try ( FileReader fr = new FileReader(file)) {
                BufferedReader br = new BufferedReader(fr);
                sb = new StringBuffer();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                    sb.append("\n");
                }
            }
            System.out.println("Contents of File: ");
            System.out.println(sb.toString());
        } catch (IOException e) {
        }
    }

    public void Mac() {
        try {
            File file = new File("C:\\Users\\USER\\Desktop\\VCLA\\graphics\\system requirements for mac.txt");
            StringBuffer sb;
            try ( FileReader fr = new FileReader(file)) {
                BufferedReader br = new BufferedReader(fr);
                sb = new StringBuffer();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                    sb.append("\n");
                }
            }
            System.out.println("Contents of File: ");
            System.out.println(sb.toString());
        } catch (IOException e) {
        }
    }

    ///// setup of adobe photoshop
    @Override
    public void setup1() {

        Desktop desk = Desktop.getDesktop();
        try {
            // now we enter our URL that we want to open in our
            // default browser
            desk.browse(new URI("https://helpx.adobe.com/creative-cloud/help/download-install-Photoshop.html"));
        } catch (URISyntaxException | IOException ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    ///////setup of adobe illustrator
    @Override
    public void setup2() {

        Desktop desk = Desktop.getDesktop();
        try {
            // now we enter our URL that we want to open in our
            // default browser
            desk.browse(new URI("https://www.adobe.com/products/illustrator/free-trial-download.html"));

        } catch (URISyntaxException | IOException ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    ////setup of adobe after effects

    @Override
    public void setup3() {

        Desktop desk = Desktop.getDesktop();
        try {
            // now we enter our URL that we want to open in our
            // default browser
            desk.browse(new URI("https://www.adobe.com/products/aftereffects.html"));
        } catch (URISyntaxException | IOException ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}

public class Test {

    public static void main(String[] args) {
        //public static final String TEXT_YELLOW = "\u001B[33m"; 
        Scanner sc = new Scanner(System.in);
        programming_language pl = new programming_language();
        Graphics gp = new Graphics();
        System.out.println("\n\t\t\t=====================================================================\n");
        System.out.println("\t\t\t=                          =COMPUTER LAB ASSISTANT=\t\t\t=\n");
        System.out.println("\t\t\t======================================================================\n");
        System.out.println("\t\t\t=               DEVELOPED BY MD. ASAD MONDALL(20CSE006)\t\t=\n");
        System.out.println("\t\t\t======================================================================\n");
        System.out.println("\t#CATEGORY-A : PROGRAMMING LANGUAGE\n");
        //System.out.println(TEXT_RED + "This text is red!" + TEXT_RESET);
        System.out.println("\t1.C/C++ \n");
        System.out.println("\t2.JAVA \n");
        System.out.println("\t3.PYTHON \n");
        System.out.println("\t#CATEGORY-B : GRAPHICS\n");
        System.out.println("\t4.ADOBE PHOTOSHOP \n");
        System.out.println("\t5.ADOBE ILLUSTRATOR \n");
        System.out.println("\t6.ADOBE AFTER EFFECTS \n");
        System.out.println("\t#CATEGORY-C : SYLLABUS\n");
        System.out.println("\t7.COURSE SYLLABUS \n");
        System.out.println("\t8.EXIT \n");
        System.out.println("\tPLEASE SELECT ANY OPTION: \n");
        int opt = sc.nextInt();
        switch (opt) {
            case 1:
                System.out.println("\t CHOOSE YOUR OPERATING SYSTEM :\n");
                System.out.println("\t1.Windows\n");
                System.out.println("\t2.Mac\n");
                System.out.println("\t3.Linux\n");
                int choose1 = sc.nextInt();
                switch (choose1) {
                    case 1 ->
                        pl.Windows();
                    case 2 ->
                        pl.Mac();
                    case 3 ->
                        pl.Linux();
                }
                System.out.println("\t TO SETUP C/C++, ENTER '1' & TO EXIT ENTER '0' :\n");
                int choose2 = sc.nextInt();
                switch (choose2) {
                    case 1 -> {
                        pl.setup1();
                        exit(0);
                    }
                    case 0 ->
                        exit(0);
                }

            case 2:
                System.out.println("\t CHOOSE YOUR OPERATING SYSTEM :\n");
                System.out.println("\t1.Windows\n");
                System.out.println("\t2.Mac\n");
                System.out.println("\t3.Linux\n");
                int choose3 = sc.nextInt();
                switch (choose3) {
                    case 1 ->
                        pl.Windows();
                    case 2 ->
                        pl.Mac();
                    case 3 ->
                        pl.Linux();
                }
                System.out.println("\t TO SETUP JAVA, ENTER '1' & TO EXIT ENTER '0' :\n");
                int choose4 = sc.nextInt();
                switch (choose4) {
                    case 1 -> {
                        pl.setup2();
                        exit(0);
                    }
                    case 0 ->
                        exit(0);
                }

            case 3:
                System.out.println("\t CHOOSE YOUR OPERATING SYSTEM :\n");
                System.out.println("\t1.Windows\n");
                System.out.println("\t2.Mac\n");
                System.out.println("\t3.Linux\n");
                int choose5 = sc.nextInt();
                switch (choose5) {
                    case 1 ->
                        pl.Windows();
                    case 2 ->
                        pl.Mac();
                    case 3 ->
                        pl.Linux();
                }
                System.out.println("\t TO SETUP PYTHON, ENTER '1' & TO EXIT ENTER '0' :\n");
                int choose6 = sc.nextInt();
                switch (choose6) {
                    case 1 -> {
                        pl.setup3();
                        exit(0);
                    }
                    case 0 ->
                        exit(0);
                }

            case 4:
                System.out.println("\t CHOOSE YOUR OPERATING SYSTEM :\n");
                System.out.println("\t1.Windows\n");
                System.out.println("\t2.Mac\n");
                System.out.println("\t3.Linux\n");
                int choose7 = sc.nextInt();
                switch (choose7) {
                    case 1 ->
                        gp.Windows();
                    case 2 ->
                        gp.Mac();
                    case 3 ->
                        gp.Linux();
                }
                System.out.println("\t TO SETUP ADOBE PHOTOSHOP, ENTER '1' & TO EXIT ENTER '0' :\n");
                int choose8 = sc.nextInt();
                switch (choose8) {
                    case 1 -> {
                        gp.setup1();
                        exit(0);
                    }
                    case 0 ->
                        exit(0);
                }

            case 5:
                System.out.println("\t CHOOSE YOUR OPERATING SYSTEM :\n");
                System.out.println("\t1.Windows\n");
                System.out.println("\t2.Mac\n");
                System.out.println("\t3.Linux\n");
                int choose9 = sc.nextInt();
                switch (choose9) {
                    case 1 ->
                        gp.Windows();
                    case 2 ->
                        gp.Mac();
                    case 3 ->
                        gp.Linux();
                }
                System.out.println("\t TO SETUP ADOBE ILLUSTRATOR, ENTER '1' & TO EXIT ENTER '0' :\n");
                int choose10 = sc.nextInt();
                switch (choose10) {
                    case 1 -> {
                        gp.setup2();
                        exit(0);
                    }
                    case 0 ->
                        exit(0);
                }

            case 6:
                System.out.println("\t CHOOSE YOUR OPERATING SYSTEM :\n");
                System.out.println("\t1.Windows\n");
                System.out.println("\t2.Mac\n");
                System.out.println("\t3.Linux\n");
                int choose11 = sc.nextInt();
                switch (choose11) {
                    case 1 ->
                        gp.Windows();
                    case 2 ->
                        gp.Mac();
                    case 3 ->
                        gp.Linux();
                }
                System.out.println("\t TO SETUP ADOBE AFTER EFFECTS, ENTER '1' & TO EXIT ENTER '0' :\n");
                int choose12 = sc.nextInt();
                switch (choose12) {
                    case 1 -> {
                        gp.setup3();
                        exit(0);
                    }
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
                    case 0 ->
                        exit(0);
                }

            case 7:
                Software.course_syllabus();
                break;
            case 8:
                exit(0);
        }
    }
}
